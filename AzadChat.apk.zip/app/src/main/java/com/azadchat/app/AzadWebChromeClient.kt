package com.azadchat.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.MediaStore
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File

/**
 * AzadChat v1.61 — مجوز میکروفون و دوربین مستقیم از خودِ اندروید + انتخاب فایل/عکس (گالری یا دوربین).
 * فقط برای دامنهٔ allowedHost مجوز می‌دهد.
 */
class AzadWebChromeClient(
    private val activity: ComponentActivity,
    private val allowedHost: String
) : WebChromeClient() {

    private var pending: PermissionRequest? = null
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var pendingParams: WebChromeClient.FileChooserParams? = null
    private var cameraUri: Uri? = null

    // نگاشت «منبع وب» ← «مجوز اندروید»
    private val map = linkedMapOf(
        PermissionRequest.RESOURCE_AUDIO_CAPTURE to Manifest.permission.RECORD_AUDIO,
        PermissionRequest.RESOURCE_VIDEO_CAPTURE to Manifest.permission.CAMERA
    )

    private fun has(p: String): Boolean =
        ContextCompat.checkSelfPermission(activity, p) == PackageManager.PERMISSION_GRANTED

    private val launcher = activity.registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        val req = pending
        pending = null
        if (req != null) finish(req)
    }

    private val camPermLauncher = activity.registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        launchChooser()
    }

    private val fileLauncher = activity.registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { res ->
        val cb = filePathCallback
        filePathCallback = null
        var result: Array<Uri>? = null
        if (res.resultCode == Activity.RESULT_OK) {
            val data = res.data
            val clip = data?.clipData
            val single = data?.data
            val cam = cameraUri
            if (clip != null && clip.itemCount > 0) {
                result = Array(clip.itemCount) { i -> clip.getItemAt(i).uri }
            } else if (single != null) {
                result = arrayOf(single)
            } else if (cam != null) {
                result = arrayOf(cam)
            }
        }
        cameraUri = null
        cb?.onReceiveValue(result)
    }

    /** منابعی را که مجوز اندرویدشان داده شده تأیید می‌کند؛ اگر هیچ‌کدام نبود رد می‌کند. */
    private fun finish(req: PermissionRequest) {
        val ok = req.resources.filter { r -> map[r]?.let { has(it) } == true }
        if (ok.isEmpty()) req.deny() else req.grant(ok.toTypedArray())
    }

    override fun onPermissionRequest(request: PermissionRequest) {
        activity.runOnUiThread {
            val host = request.origin?.host
            val wanted = request.resources.filter { map.containsKey(it) }
            if (host != allowedHost || wanted.isEmpty()) {
                request.deny()
            } else {
                val missing = wanted.mapNotNull { map[it] }.filter { !has(it) }
                if (missing.isEmpty()) {
                    request.grant(wanted.toTypedArray())
                } else {
                    pending?.deny()
                    pending = request
                    launcher.launch(missing.toTypedArray())
                }
            }
        }
    }

    override fun onPermissionRequestCanceled(request: PermissionRequest) {
        if (pending === request) pending = null
    }

    // ---------- انتخاب فایل / عکس گرفتن ----------

    override fun onShowFileChooser(
        webView: WebView,
        callback: ValueCallback<Array<Uri>>,
        params: WebChromeClient.FileChooserParams
    ): Boolean {
        filePathCallback?.onReceiveValue(null)
        filePathCallback = callback
        pendingParams = params
        if (params.isCaptureEnabled && !has(Manifest.permission.CAMERA)) {
            camPermLauncher.launch(Manifest.permission.CAMERA)
        } else {
            launchChooser()
        }
        return true
    }

    private fun launchChooser() {
        val params = pendingParams
        val cb = filePathCallback
        pendingParams = null
        if (params == null || cb == null) return
        val acc = params.acceptTypes.filter { it.isNotBlank() }
        val wantsImage = acc.isEmpty() || acc.any { it.startsWith("image") || it.startsWith("*/") }
        val camera: Intent? =
            if (wantsImage && has(Manifest.permission.CAMERA)) makeCameraIntent() else null
        val intent: Intent
        if (params.isCaptureEnabled && camera != null) {
            intent = camera
        } else {
            intent = Intent(Intent.ACTION_CHOOSER)
            intent.putExtra(Intent.EXTRA_INTENT, params.createIntent())
            if (camera != null) {
                intent.putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(camera))
            }
        }
        try {
            fileLauncher.launch(intent)
        } catch (e: Exception) {
            filePathCallback = null
            cameraUri = null
            cb.onReceiveValue(null)
        }
    }

    private fun makeCameraIntent(): Intent? {
        return try {
            val dir = File(activity.cacheDir, "camera")
            dir.mkdirs()
            val f = File.createTempFile("IMG_", ".jpg", dir)
            val uri = FileProvider.getUriForFile(activity, activity.packageName + ".fileprovider", f)
            cameraUri = uri
            val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            i.putExtra(MediaStore.EXTRA_OUTPUT, uri)
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            i
        } catch (e: Exception) {
            null
        }
    }
}
